# No custom rules required for this simple WebView application.
