# Checklist sebelum Play Store

- [ ] Ganti email kontak di privacy policy
- [ ] Publish privacy policy di HTTPS
- [ ] Isi Data Safety berdasarkan data nyata website
- [ ] Uji login/admin
- [ ] Uji daftar anggota
- [ ] Uji upload foto
- [ ] Uji link WhatsApp
- [ ] Uji tombol Back
- [ ] Uji Android 13/14/15/16 jika tersedia
- [ ] Buat signing key dan backup aman
- [ ] Generate AAB release
- [ ] Upload AAB ke Play Console internal testing
- [ ] Selesaikan persyaratan testing/verification akun developer jika diminta Google
