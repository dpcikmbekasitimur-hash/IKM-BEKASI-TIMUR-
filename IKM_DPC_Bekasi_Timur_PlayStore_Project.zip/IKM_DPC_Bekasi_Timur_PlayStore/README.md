# IKM DPC Bekasi Timur — Android / Google Play project

A clean Android WebView wrapper for:

https://ikmdpcbekasitimur.blogspot.com/

## App identity
- App name: IKM DPC Bekasi Timur
- Package ID: com.ikmdpcbekasitimur.app
- Version: 1.0.0 (versionCode 1)
- Target SDK: 36
- Only requested Android permission: INTERNET
- App icon: the latest IKM DPC Bekasi Timur design supplied for this project

## Security choices
- HTTPS only; cleartext HTTP is disabled.
- WebView Safe Browsing is enabled where supported.
- Local file access from web content is disabled.
- Mixed HTTP/HTTPS content is blocked.
- Third-party cookies are disabled.
- Only the IKM Blogger host stays inside the WebView. External links are opened by Android.
- No advertising SDKs, analytics SDKs, location, contacts, SMS, Bluetooth, NFC, or phone permissions are included.
- The system file picker is used for website upload fields, so broad storage permissions are not requested.

## Build in Android Studio
1. Install a current Android Studio release with Android SDK Platform 36.
2. Open this folder as an existing Gradle project.
3. Let Android Studio download the Android Gradle Plugin/Gradle components it requests.
4. For a test APK: Build > Generate App Bundles or APKs > Generate APKs.
5. For Google Play: Build > Generate Signed Bundle / APK > Android App Bundle.
6. Create and securely back up the upload/signing key. Do not publish the keystore or passwords.

## Important before Play Store submission
The website itself may collect/process member data. Complete the Play Console Data safety form based on the actual website behavior and provide a public privacy-policy URL that accurately describes what the website/app collects and why.

Do not claim that the app collects no data merely because this Android wrapper has no analytics SDK.

## Privacy policy starter
See PRIVACY_POLICY_TEMPLATE.md. Replace the placeholders and publish the final policy on a public HTTPS page before Play Store submission.
