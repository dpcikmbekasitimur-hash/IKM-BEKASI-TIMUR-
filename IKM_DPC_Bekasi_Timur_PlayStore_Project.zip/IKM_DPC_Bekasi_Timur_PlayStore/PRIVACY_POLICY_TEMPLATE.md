# Kebijakan Privasi — IKM DPC Bekasi Timur

**Terakhir diperbarui:** [ISI TANGGAL]

Aplikasi **IKM DPC Bekasi Timur** menyediakan akses Android ke situs resmi IKM DPC Bekasi Timur di https://ikmdpcbekasitimur.blogspot.com/.

## Data yang diproses
Aplikasi Android ini tidak menambahkan layanan iklan, analitik, lokasi, kontak, SMS, Bluetooth, NFC, atau pelacakan pihak ketiga. Namun, situs IKM yang dibuka di dalam aplikasi dapat memproses data yang dikirimkan pengguna melalui formulir atau fitur situs, misalnya data pendaftaran anggota dan foto. Jelaskan secara spesifik semua data yang benar-benar dikumpulkan oleh situs dan layanan Google/Google Apps Script yang digunakan.

## Penggunaan data
Data digunakan untuk tujuan yang dijelaskan pada formulir dan layanan IKM DPC Bekasi Timur, misalnya administrasi anggota. Jangan mencantumkan tujuan yang tidak benar-benar dilakukan.

## Penyimpanan dan pihak ketiga
Jelaskan di sini tempat data disimpan, layanan pihak ketiga yang menerima data, dan berapa lama data disimpan. Jika menggunakan Google Sheets/Google Apps Script, jelaskan secara akurat.

## Hak pengguna
Jelaskan cara pengguna meminta koreksi atau penghapusan data dan siapa yang dapat dihubungi.

## Kontak
Email: [EMAIL RESMI IKM]

> Catatan: dokumen ini adalah template dan harus disesuaikan dengan praktik pengolahan data yang sebenarnya sebelum dipublikasikan.
